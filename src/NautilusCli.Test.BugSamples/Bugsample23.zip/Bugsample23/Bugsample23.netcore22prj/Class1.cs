﻿using System;

namespace Bugsample23.netcore22prj
{
	public class Class1
	{
	}
}
